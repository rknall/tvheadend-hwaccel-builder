The files in this preview folder are provided as a preview of upcoming features.
The content of this folder may be changed or removed without respect for backward compatibility.